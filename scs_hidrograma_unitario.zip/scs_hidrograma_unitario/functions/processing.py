from qgis.PyQt.QtWidgets import QMessageBox
import processing
from qgis.core import (
    QgsVectorLayer,
    QgsProject,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsWkbTypes,
    QgsRasterLayer,
    QgsRasterBandStats,
    QgsField,
    QgsProject
)
from qgis.PyQt.QtCore import QVariant
import os


def run_your_code():
    # Verifica se o projeto atual tem um caminho de arquivo associado
    if not QgsProject.instance().fileName():
        # Se não tiver um caminho de arquivo, o projeto não foi salvo
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText("O projeto não foi salvo.")
        msg.setInformativeText("Você deve salvar o seu projeto antes de continuar.")
        msg.setStandardButtons(QMessageBox.Cancel)

        
        # Exibe a caixa de diálogo e obtém a resposta do usuário
        ret = msg.exec_()

        return False
    else:
        return True


def delete_shapefile_and_layer(layer_name):

    # Itera sobre as camadas do projeto para encontrar a desejada
    for layer in QgsProject.instance().mapLayers().values():
        if layer.name() == layer_name:
            # Obter o caminho da origem da camada
            layer_source = layer.source()
            layer_dir = os.path.dirname(layer_source)
            base_name = os.path.splitext(os.path.basename(layer_source))[0]
            
            # Remove a camada do QGIS
            QgsProject.instance().removeMapLayer(layer.id())
            print(f"Camada '{layer_name}' foi removida do QGIS.")
            # Apaga os arquivos associados ao shapefile
            extensions = [".shp", ".shx", ".dbf", ".prj", ".qpj", ".cpg"]
            for ext in extensions:
                file_path = os.path.join(layer_dir, base_name + ext)
                if os.path.exists(file_path):
                    os.remove(file_path)
                    print(f"Arquivo deletado: {file_path}")
            return

    pass




def cria_pontos_delta_H(shapefile_path):

    # Carrega o Shapefile como uma camada
    input_layer = QgsVectorLayer(shapefile_path, "camada_linha", "ogr")
    
    # Verifica se a camada é válida e do tipo linha
    if not input_layer.isValid():
        print("Erro: Não foi possível carregar o Shapefile!")
        return None
    if input_layer.geometryType() != QgsWkbTypes.LineGeometry:
        print("Erro: O Shapefile não contém geometrias do tipo linha!")
        return None

    # Cria uma camada de pontos na memória
    endpoint_layer = QgsVectorLayer(
        "Point?crs={}".format(input_layer.crs().authid()),
        "extremidades_linha",
        "memory"
    )
    provider = endpoint_layer.dataProvider()
    provider.addAttributes([QgsField("tipo", QVariant.String)])  # Campo para marcar "início" ou "fim"
    endpoint_layer.updateFields()

    # Processa cada feição da camada de linha
    for feature in input_layer.getFeatures():
        geom = feature.geometry()
        if not geom.isMultipart():
            # Linha simples: extrai primeiro e último vértice
            points = geom.asPolyline()
            if len(points) >= 2:
                start_point = QgsFeature()
                start_point.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(points[0])))
                start_point.setAttributes(["início"])
                provider.addFeature(start_point)

                end_point = QgsFeature()
                end_point.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(points[-1])))
                end_point.setAttributes(["fim"])
                provider.addFeature(end_point)
        else:
            # Multilinhas: processa cada parte separadamente
            for part in geom.asMultiPolyline():
                if len(part) >= 2:
                    start_point = QgsFeature()
                    start_point.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(part[0])))
                    start_point.setAttributes(["início"])
                    provider.addFeature(start_point)

                    end_point = QgsFeature()
                    end_point.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(part[-1])))
                    end_point.setAttributes(["fim"])
                    provider.addFeature(end_point)

    # Adiciona a camada ao projeto
    QgsProject.instance().addMapLayer(endpoint_layer)
    return endpoint_layer

def clip_calculo_CN_medio(project_directory, bacia_path, CN_path):


    # Faz o recorte da camada CN.tif de acordo com a delimitação da bacia
    output_raster_path = project_directory + "/CN_Bacia.tif"
    processing.run("gdal:cliprasterbymasklayer", {
        'INPUT': CN_path,
        'MASK': bacia_path,
        'SOURCE_CRS': None,
        'TARGET_CRS': None,
        'TARGET_EXTENT': None,
        'NODATA': None,
        'ALPHA_BAND': False,
        'CROP_TO_CUTLINE': True,
        'KEEP_RESOLUTION': False,
        'SET_RESOLUTION': False,
        'X_RESOLUTION': None,
        'Y_RESOLUTION': None,
        'MULTITHREADING': False,
        'OPTIONS': '',
        'DATA_TYPE': 0,
        'EXTRA': '',
        'OUTPUT': output_raster_path
    })

    # Carregar o raster como uma camada
    raster_layer = QgsRasterLayer(output_raster_path, "CN Recortado")

    if not raster_layer.isValid():
        print("Erro ao carregar o raster.")
        return None
    else:
        # Adicionar a camada ao painel do QGIS
        QgsProject.instance().addMapLayer(raster_layer)
        print("Camada recortada adicionada ao painel do QGIS.")

        # Obter estatísticas do primeiro canal/banda
        band_number = 1  # Banda 1
        provider = raster_layer.dataProvider()
        stats = provider.bandStatistics(band_number, QgsRasterBandStats.All)

        # Valor médio da banda
        CN = stats.mean

    return CN
