from qgis.core import QgsVectorLayer,QgsRasterLayer
from qgis.PyQt.QtWidgets import QMessageBox
from qgis.core import QgsVectorLayer, QgsRasterLayer
import os




def retorna_crs(self, file_path):
 ## Verifica se o arquivo existe
    if not os.path.exists(file_path):
        return None


        # Determina se é vetor ou raster baseado na extensão do arquivo
    if file_path.lower().endswith(('.shp', '.geojson', '.gml', '.kml', '.gpkg')):  # formatos comuns de vetor
        layer = QgsVectorLayer(file_path, "temporary_layer", "ogr")
    elif file_path.lower().endswith(('.tif', '.tiff', '.img', '.dem', '.nc', '.asc')):  # formatos comuns de raster
        layer = QgsRasterLayer(file_path, "temporary_layer")
    else:
        return None

    if not layer.isValid():
        print(f"Falha ao carregar a camada de {file_path}, verifique a existência do arquivo e as permissões")
        return None

    return layer.crs().authid()

def verifica_sistema_metrico(parent, layer_path):
    layer = QgsVectorLayer(layer_path, "Vector Layer", "ogr")

    if not layer.isValid():
        QMessageBox.critical(parent, f"Camada inválida ao verificar sistema métrico de {layer_path.split('/')[-1]}!", "Mensagem de erro")
        return False

    crs = layer.crs()

    if crs.isGeographic():
        print(f"Sistema de coordenadas de {layer_path.split('/')[-1]}: ({crs.authid()}), é geográfico (graus).")
        metrico = False
    else:
        print(f"Sistema de coordenadas de {layer_path.split('/')[-1]}: ({crs.authid()}), é projetado (metros ou similar).")
        metrico = True

    return metrico