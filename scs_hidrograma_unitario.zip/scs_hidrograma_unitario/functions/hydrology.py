from qgis.core import QgsVectorLayer, QgsGeometry, QgsProject, QgsCoordinateReferenceSystem, QgsCoordinateTransform
from PyQt5.QtWidgets import QMessageBox, QWidget
import processing
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import norm
import os

def calcula_delta_H(pontos_criados, raster_path):
    try:
        # Executa o sampling diretamente em uma camada de memória
        result = processing.run("native:rastersampling", {
            'INPUT': pontos_criados,
            'RASTERCOPY': raster_path,
            'COLUMN_PREFIX': 'SAMPLE_',
            'OUTPUT': 'memory:' 
        })
    except Exception as e:
        QMessageBox.warning(QWidget(), "Erro", "Erro ao extrair alturas do MDE: " + str(e))
        return None

    # Acessa a camada em memória gerada pelo processing
    layer = result['OUTPUT']
    if not layer.isValid():
        QMessageBox.warning(QWidget(), "Erro", "Camada de pontos inválida!")
        return None

    # Extrai os valores de altitude sem criar arquivos
    vector = []
    field_name = 'SAMPLE_1'
    
    if field_name not in layer.fields().names():
        QMessageBox.warning(QWidget(), "Erro", "Atributo de altitude não encontrado.")
        return None

    for feature in layer.getFeatures():
        attribute_value = feature[field_name]
        if attribute_value is not None:  # Ignora valores nulos
            vector.append(attribute_value)

    # Remove valores 99999 (se existirem)
    vector = [v for v in vector if v < 99999]

    if vector:
        delta_h = max(vector) - min(vector)
        print(f"Alturas válidas: {vector} metros")
        print(f"Delta H (Talvegue): {delta_h} metros")
        return delta_h,  max(vector), min(vector)
    else:
        print("Nenhum valor de altitude válido encontrado.")
        return None, None ,None



def calcula_area_bacia(EPSG,caminho_shapefile, parent=None):

    try:
    
        layer = QgsVectorLayer(caminho_shapefile, "Bacia.shp", "ogr")

        if not layer.isValid():
            QMessageBox.warning(parent, "Erro", f"Erro ao carregar {caminho_shapefile.split('/')[-1]} no campo Canal Principal!")
            return None

        print("Camada Bacia.shp carregada com sucesso.")
        crs_metrico = QgsCoordinateReferenceSystem('EPSG:' + EPSG)
        crs_original = layer.crs()

        total_area = 0
        for feature in layer.getFeatures():
            geom = feature.geometry()
            if geom:
                geom_metrico = QgsGeometry(geom)
                geom_metrico.transform(QgsCoordinateTransform(crs_original, crs_metrico, QgsProject.instance()))
                total_area += geom_metrico.area()

        print(f"Área calculada: {total_area / 1e6:.4f} km²")
        return total_area / 1e6
    

    except Exception as e:
        QMessageBox.warning(parent, "Erro", f"Erro ao calcular area da Bacia!")
        print(f"[ERRO] {e}")
        

def calcula_Tc(total_length, delta_h):

    L_km = total_length/1000
    D = delta_h/total_length
    Tc = 3.989 * ((L_km** 0.77) / (D**0.385))#Kirpich
    
    return Tc
        

def UH_CSC(Tc, area_km, d_):    
    
    Tc_min = Tc*60
    tp = 0.6 * Tc_min
    Tp = tp + d_ / 2  # tempo até o pico (min)
    tb = Tp + 1.67*Tp  # duração total do hidrograma (min)
    Tph = Tp / 60    # tempo ao pico em horas
    qp = (0.208*area_km)/Tph
    
    # Vetor de tempo
    t = np.arange(0, tb*1.25, d_)  # de 0 até tb, com passo tb/n_intervalos
    
    # Cálculo do hidrograma SCS
    Q = np.exp(3.7) * ((t / Tp) ** 3.7) * np.exp(-3.7 * (t / Tp)) * qp
    Q = np.nan_to_num(Q)  # Substitui eventuais NaNs por zero (quando t=0)             
    
    
    triang=[]
    for tempo in t:
        if tempo <= Tp:
            triang.append((tempo/Tp)*qp)
        else:
            if tempo <= tb:
                triang.append((tb - tempo)/(tb-Tp)*qp)
            else:
                triang.append(0)
    
    # Plotando o hidrograma
    plt.figure(figsize=(8, 5))
    plt.plot(t, Q, label="SCS - Curvilíneo", color='blue', marker='o')
    plt.plot(t, triang, label="SCS - Triangular", color='green', marker='o')
    plt.xlabel("Tempo (min)")
    plt.ylabel("Vazão (m³/s)")
    plt.title("Hidrograma Unitário - Método SCS")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.show()

    return Q, qp, Tp, tb

def intensidade_chuva_IDF_simples(TR, t0, a1, b1, c1, d1, a2, b2, c2, d2, t1min, t1max, t2min, t2max):
    if (t0 >= t2min) and (t0 <= t2max):
       I0 = (a1 * (TR**b1)) / ((t0 + c1)**d1)
    else:
        I0 = (a2 * (TR**b2)) / ((t0 + c2)**d2)
    return I0
def intensidade_chuva_IDF(TR, t, a1, b1, c1, d1, a2, b2, c2, d2, t1min, t1max, t2min, t2max):

    # Inicializar array de resultados
    i = np.zeros_like(t, dtype=float)
    
    # Máscara para o primeiro intervalo 
    mask1 = (t >= t1min) & (t < t1max)
    if np.any(mask1):
        i[mask1] = (a1 * (TR**b1)) / ((t[mask1] + c1)**d1)
    
    # Máscara para o segundo intervalo 
    mask2 = (t >= t2min) & (t <= t2max)
    if np.any(mask2):
        i[mask2] = (a2 * (TR**b2)) / ((t[mask2] + c2)**d2)

        # Plotando
    plt.figure(figsize=(8, 5))
    plt.plot(t, i, marker='o', linestyle='-', color='b', label='Intensidade')
    
    #Personalizando o gráfico
    plt.xlabel('Tempo (min)')
    plt.ylabel('Intensidade (mm/h)')
    plt.title(f'Gráfico de I X t (TR = {TR})')
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()

    
    return np.array(i) , t



def distribuicao_chuva_alternados(t, I, T, debug=False):
     
    P = t/60 * I
    
    # Validação dos dados
    t = np.array(t)
    P = np.array(P)
    if len(t) != len(P):
        raise ValueError("t e P devem ter o mesmo comprimento.")
    if not np.all(np.diff(t) > 0):
        raise ValueError("Durações (t) devem estar em ordem crescente.")
    if not np.all(np.diff(P) >= 0):
        raise ValueError("Precipitações (P) devem ser crescentes.")
    
    # Cálculo dos incrementos
    P_incrementos = np.concatenate(([P[0]], np.diff(P)))
    if debug:
        print("Incrementos originais:", P_incrementos)
    
    # Ordena em ordem decrescente
    incrementos_ordenados = sorted(P_incrementos, reverse=True)
    
    # Posição do pico (entre 1/3 e 1/2 da duração total)
    duracao_total = t[-1]
    pico_idx = np.argmin(np.abs(t - duracao_total / 2))  # Índice mais próximo da metade
    
    # Redistribuição
    hietograma = [None] * len(t)
    hietograma[pico_idx] = incrementos_ordenados[0]
    
    esquerda = pico_idx - 1
    direita = pico_idx + 1
    for i, valor in enumerate(incrementos_ordenados[1:], 1):
        if i % 2 == 1 and esquerda >= 0:  # Ímpar: esquerda
            hietograma[esquerda] = valor
            esquerda -= 1
        elif direita < len(t):  # Par: direita
            hietograma[direita] = valor
            direita += 1


    return P_incrementos, np.array(hietograma)




def calcular_precipitacao_efetiva_scs(t, P_dist, CN):

    P = np.cumsum(P_dist)
    
    # Calcular S (capacidade máxima de retenção do solo)
    S = (25400 / CN) - 254
    
    # Limiar para início do escoamento
    limiar = 0.2 * S
    
    # Calcular Pe para cada valor de P
    Pe = np.where(P > limiar, (P - limiar)**2 / (P + 0.8 * S), 0)

    diffs = np.diff(Pe)  # Calcula as diferenças: [2, 0, 1, 1, 1]
    Pe_incr = np.concatenate([[Pe[0]], diffs])  # Junta [0] com as diferenças

    plt.figure(figsize=(8, 5))

    n_barras = len(t)
    espacamento = 0.5  # Espaço entre as barras
    
    # Posições das barras (começando em 0, com espaçamento fixo)
    posicoes = np.arange(n_barras) * espacamento
    
    # Gráfico de barras
    
    plt.bar(posicoes, P_dist, width=espacamento*0.8, color='blue', label='Precipitação (mm) ',
            edgecolor='black', linewidth=0.5)
    plt.bar(posicoes, Pe_incr, width=espacamento*0.6, color='green', label='Precipiitação Efetiva',
            edgecolor='black', linewidth=0.5)
    
    # Define os rótulos do eixo x como os valores originais de t (com 1 casa decimal)
    plt.xticks(posicoes, [f'{valor:.1f}' for valor in t])  # Formatação direta
    
    plt.xlabel('Tempo (min)')
    plt.ylabel('Precipitação (mm)')
    plt.title(f'Chuva distribuída')
    plt.grid(True, axis='y', linestyle='--', alpha=0.7)
    plt.legend()
    plt.tight_layout()
    plt.show()

    
    return Pe, np.array(Pe_incr), limiar





def Hidrograma_Unitario(Tp, tb, d_, qp_linha):
    

    Tph = Tp / 60    # tempo ao pico em horas

    
    # Vetor de tempo
    t = np.arange(0, tb*1.25, d_)

    
    # Cálculo do hidrograma SCS
    Q = (np.exp(3.7) * ((t / Tp) ** 3.7) * np.exp(-3.7 * (t / Tp)) * qp_linha) 
    Q = np.nan_to_num(Q)  # Substitui eventuais NaNs por zero (quando t=0)             
    
    
    triang=[]
    for tempo in t:
        if tempo <= Tp:
            triang.append((tempo/Tp)*qp_linha)
        else:
            if tempo <= tb:
                triang.append((tb - tempo)/(tb-Tp)*qp_linha)
            else:
                triang.append(0)

    return triang, t


def hidrogramas_para_cada_bloco(t, Tp, tb, d_, qp_linha):

    i = 0
    triang_array = []
    plt.figure(figsize=(8, 5))
    
    # Criar um mapa de cores com tantas cores quantas curvas
    colors = plt.cm.rainbow(np.linspace(0, 1, len(t)))
    
    for inicio in t:
        triang, t_linha = Hidrograma_Unitario(Tp, tb, d_, qp_linha[i])
        
        if i != 0:
            triang_z = np.concatenate([np.zeros(i), np.array(triang)])
            t_adjusted = np.concatenate([np.arange(i) * d_, t_linha + i * d_])
        else:
            triang_z = triang
            t_adjusted = t_linha
    
        
        triang_array.append(triang_z)
        plt.plot(t_adjusted, triang_z, 
                 label=f"Bloco {i+1} ({int(inicio)} min)", 
                 color=colors[i],  # Usa a i-ésima cor do mapa
                 marker='o', 
                 markersize=3)
        i += 1

    tb_linha = tb + t 

    
    # Padronizar os vetores
    max_length = max(len(v) for v in triang_array)
    triang_array_padded = [np.pad(v, (0, max_length - len(v)), 'constant') for v in triang_array]
    
    # Criar vetor de tempo ajustado para o hidrograma de projeto
    t_final = np.arange(max_length) * d_
    
    # Plotar hidrograma de projeto
    plt.plot(t_final, np.sum(triang_array_padded, axis=0),
             label="Hidrograma de Projeto",
             color='black',
             linewidth=2,
             linestyle='--')
    
    plt.xlabel("Tempo (min)", fontsize=12)  
    plt.ylabel("Vazão (m³/s)", fontsize=12)
    plt.title("Hidrograma Unitário - Método SCS", fontsize=14)
    
    # Configurar a legenda para ficar fora do gráfico
    plt.legend(bbox_to_anchor=(1.05, 1),  # Posiciona à direita fora do gráfico
               loc='upper left',
               borderaxespad=0.,
               fontsize=9,
               title="Blocos de Chuva",
               title_fontsize=10)
    
    plt.grid(True, linestyle='--', alpha=0.6)
    plt.tight_layout()  # Ajusta o layout para acomodar a legenda
    plt.show()

    Q_max = max(np.sum(triang_array_padded, axis=0))

    Q_total = np.sum(triang_array_padded, axis=0)
    Q_max = np.max(Q_total)
    t_Qmax = t_final[np.argmax(Q_total)]

    return triang_array_padded, t_adjusted, Q_max,t_Qmax


def DataFrame_Convolucao(t, P, Pe, Pe_incr, Tp, tb, qp_linha, t_adjusted, triang_array_padded, output_dir):
    Tp_linha = Tp + t
    tb_linha =tb + t
    df = pd.concat([pd.Series(P), pd.Series(np.cumsum(P)),pd.Series(Pe),pd.Series(Pe_incr), pd.Series(Tp_linha), pd.Series(tb_linha), pd.Series(qp_linha)], names = ('P (mm)', 'P_acm', 'Pe', 'Pe_incr', "Tp'", "qp'"),  axis =1)
    df.columns = ('P (mm)', 'P_acm', 'Pe', 'Pe_incr', "Tp'", "tb'", "qp'")
    output_path = os.path.join(output_dir, 'Convolucão_HU.xlsx')
    df.to_excel(output_path)
    final = pd.concat([df, pd.DataFrame(pd.DataFrame(triang_array_padded).T)], axis =1)
    final.index = t_adjusted